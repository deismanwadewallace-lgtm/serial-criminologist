HOW TO USE THIS EXPORT
=======================
1. Copy index.html and css/styles.css into your serial-criminologist repo, overwriting the existing files at those paths.
2. Add a real portrait photo at assets/wade-deisman-portrait.jpg (referenced by the new hero). Until you do, that <img> will show a broken-image icon.
3. All other pages (about.html, contact.html, etc.) still use the OLD styles.css classes/colors (red "signal" accent) since this pass only covered the homepage. Their HTML doesn't need to change, but once you swap in the new css/styles.css, their red accents become olive automatically because the class names are the same — the shared design tokens now point to the new palette. Headers/footers on those pages will pick up the new wordmark/brand-mark styling too, though the markup for those pages' <header>/<footer> blocks would need the same brand-mark SVG + wordmark class added to fully match (currently only index.html's export includes it).
4. Commit and push as usual.
